package dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import interfaces.InterfaceProducto;
import models.TblProductocl2;


public class DaoProducto implements InterfaceProducto {

	@Override
	public void RegistrarProducto(TblProductocl2 tblpro) {
		//Establecemos conexion con la unidad de persistencia
		EntityManagerFactory conexion = Persistence.createEntityManagerFactory("LPII_CL2_CRUZESPINOZACARMI");
		EntityManager emanager = conexion.createEntityManager();
		//inica la transaccion
		emanager.getTransaction().begin();
		//registramos
		emanager.persist(tblpro);
		//mensaje
		System.out.println("Datos registrados exitosamente");
		//confirmamos
		emanager.getTransaction().commit();
		//cierre
		emanager.close();
	}
	
	@Override
	public List<TblProductocl2> ListarProdutoc() {
		//Establecemos conexion con la unidad de persistencia
		EntityManagerFactory conexion = Persistence.createEntityManagerFactory("LPII_CL2_CRUZESPINOZACARMIz");
		EntityManager emanager = conexion.createEntityManager();
		//inica la transaccion
		emanager.getTransaction().begin();
		//listamos
		List<TblProductocl2> listaEmpleado = emanager.createQuery("SELECT e FROM TblProductocl2 e",TblProductocl2.class).getResultList();
		//confirmamos
		emanager.getTransaction().commit();
		//cierre
		emanager.close();
		//retorna
		return listaEmpleado;
	}

	@Override
	public void ActualizarProducto(TblProductocl2 tblpro) {
		//Establecemos conexion con la unidad de persistencia
		EntityManagerFactory conexion = Persistence.createEntityManagerFactory("LPII_CL2_CRUZESPINOZACARMI");
		//inica la transaccion
		EntityManager emanager = conexion.createEntityManager();
		//actualizamos
		emanager.getTransaction().begin();
		//confirmamos
		emanager.merge(tblpro);
		emanager.getTransaction().commit();
		//cierre
		emanager.close();
		
	}

	@Override
	public void EliminarProducto(int id) {
		//Establecemos conexion con la unidad de persistencia
		EntityManagerFactory conexion = Persistence.createEntityManagerFactory("LPII_CL2_CRUZESPINOZACARMI");
		//inica la transaccion
		EntityManager emanager = conexion.createEntityManager();
		//eliminamos
		emanager.getTransaction().begin();
		//confirmamos
		TblProductocl2 produc = emanager.find(TblProductocl2.class, id);
		emanager.remove(produc);
		emanager.getTransaction().commit();
		//cierre
		emanager.close();
		
	}
}

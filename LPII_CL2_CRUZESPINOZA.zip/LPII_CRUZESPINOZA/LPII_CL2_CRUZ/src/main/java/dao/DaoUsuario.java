package dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import interfaces.InterfaceUsuario;
import models.TblUsuariocl2;

public class DaoUsuario implements InterfaceUsuario{

	@Override
	public TblUsuariocl2 Login(TblUsuariocl2 tblus) {
		// TODO Auto-generated method stub
        EntityManagerFactory conex = Persistence.createEntityManagerFactory("LPII_CL2_CRUZESPINOZACARMI");
		EntityManager emanager = conex.createEntityManager();
		emanager.getTransaction().begin();
		TblUsuariocl2 bus = emanager.find(TblUsuariocl2.class, tblus);
		emanager.getTransaction().commit();
		emanager.close();
		return bus;

	}
}

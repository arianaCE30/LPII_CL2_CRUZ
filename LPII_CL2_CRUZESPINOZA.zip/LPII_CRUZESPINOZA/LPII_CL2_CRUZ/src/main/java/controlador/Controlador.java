package controlador;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DaoProducto;
import dao.DaoUsuario;
import models.TblProductocl2;
import models.TblUsuariocl2;

/**
 * Servlet implementation class Controlador
 */
public class Controlador extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//recuperamos todos los campos del formulario
		DaoUsuario daousuario = new DaoUsuario();
		DaoProducto daoproduc = new DaoProducto();
		String accion = request.getParameter("accion");
		switch (accion) {
		case "login":
			String ususario = request.getParameter("usuariocl2");
			String password = request.getParameter("passwordcl2");
			TblUsuariocl2 tblus = new TblUsuariocl2();
			tblus.setUsuariocl2(ususario);
			tblus.setPasswordcl2(password);
			TblUsuariocl2 entra =  daousuario.Login(tblus);	
			request.getRequestDispatcher("registroProducto.jsp").forward(request, response);	
		break;
			
		case "registroProducto":
			String nombres = request.getParameter("nombrecl2");
			double precioVenta = Double.parseDouble(request.getParameter("precioventacl2"));
			double precioCom = Double.parseDouble(request.getParameter("preciocompcl2"));
			String estado = request.getParameter("estadocl2");
			String descrip = request.getParameter("descripcl2");
		
			TblProductocl2 tblpro = new TblProductocl2();
			
			tblpro.setNombrecl2(nombres);
			tblpro.setPrecioventacl2(precioVenta);
			tblpro.setPreciocompcl2(precioCom);
			tblpro.setEstadocl2(estado);
			tblpro.setDescripcl2(descrip);
			
			daoproduc.RegistrarProducto(tblpro);
			String mensaje = "Datos registrados";
			
			List<TblProductocl2> lista = daoproduc.ListarProdutoc();
			request.setAttribute("lista", lista);
			request.setAttribute("mensaje", mensaje);
			request.getRequestDispatcher("/Registro.jsp").forward(request, response);
			
			break;

		default:
			break;
		}
	}

}

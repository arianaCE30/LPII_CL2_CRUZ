package interfaces;
import models.*;

public interface InterfaceUsuario {
	public TblUsuariocl2 Login(TblUsuariocl2 tblus);
}

package interfaces;

import java.util.List;

import models.TblProductocl2;

public interface InterfaceProducto {
	public List<TblProductocl2> ListarProdutoc();
	public void RegistrarProducto(TblProductocl2 tblpro);
	public void ActualizarProducto(TblProductocl2 tblpro);
	public void EliminarProducto(int id);
}
